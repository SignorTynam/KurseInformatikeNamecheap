import matplotlib.pyplot as plt

def read_gas(path='1994_Weekly_Gas_Averages.txt'):
    with open(path, 'r', encoding='utf-8') as f:
        return [float(line.strip()) for line in f if line.strip()]

y = read_gas()
x = list(range(1, len(y)+1))

plt.bar(x, y, width=0.8)
plt.title('1994 — Çmimet javore të karburantit (Bar Chart)')
plt.xlabel('Java (1–52)')
plt.ylabel('USD/galon')
plt.xticks(range(1, len(y)+1, 4))
plt.xlim(0.5, len(y)+0.5)
plt.tight_layout()
plt.show()

# (Opsionale) statistika të shpejta:
print(f'Min:  {min(y):.3f} USD/gal (java {y.index(min(y))+1})')
print(f'Max:  {max(y):.3f} USD/gal (java {y.index(max(y))+1})')
print(f'Mes:  {sum(y)/len(y):.3f} USD/gal')
