import matplotlib.pyplot as plt

def read_expenses(path='expenses.txt'):
    with open(path, 'r', encoding='utf-8') as f:
        return [float(line.strip()) for line in f if line.strip()]

def main():
    values = read_expenses()
    labels = ['Rent', 'Gas', 'Food', 'Clothing', 'Car Payment', 'Misc']

    # Grafik torte me përqindje dhe orientim të qëndrueshëm
    plt.pie(
        values,
        labels=labels,
        autopct='%1.1f%%',     # shfaq % në secilën fetë
        startangle=140         # rrotullim për lexueshmëri
    )
    plt.axis('equal')          # rreth i plotë (raport 1:1)
    plt.title('Shpenzimet mujore sipas kategorive')
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    main()