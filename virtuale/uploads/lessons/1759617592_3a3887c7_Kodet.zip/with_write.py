def main():
  with open('philosophers.txt', 'w', encoding='utf-8') as f:
      f.write('John Locke\n')
      f.write('David Hume\n')
      f.write('Edmund Burke\n')

if __name__ == '__main__':
    main()