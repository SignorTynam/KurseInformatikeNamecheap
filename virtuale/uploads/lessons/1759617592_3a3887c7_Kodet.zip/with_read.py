def main():
    with open('sales.txt', 'r', encoding='utf-8') as f:
        for line in f:
            amount = float(line)
            print(f'{amount:.2f}')

if __name__ == '__main__':
    main()