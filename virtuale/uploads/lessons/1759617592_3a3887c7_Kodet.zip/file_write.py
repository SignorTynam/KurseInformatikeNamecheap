def main():
    # Hape skedarin "philosophers.txt" për shkrim.
    outfile = open('philosophers.txt', 'w')

    # Shkruaj tre emra filozofësh (secili me \n në fund).
    row1 = outfile.write('John Locke\n')
    row2 = outfile.write('David Hume\n')
    row3 = outfile.write('Edmund Burke\n')

    # Mbyll skedarin.
    outfile.close()

    # Printimi i numrit të karaktereve të shkruara në skedar.
    print(f'Numri i karaktereve të shkruara në rreshtin e parë: {row1}')
    print(f'Numri i karaktereve të shkruara në rreshtin e dytë: {row2}')
    print(f'Numri i karaktereve të shkruara në rreshtin e tretë: {row3}')


# Call the main function.
if __name__ == '__main__':
    main()