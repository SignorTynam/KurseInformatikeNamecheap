def replace_department(emp_id, new_dept):
    with open('employees.txt', 'r', encoding='utf-8') as src, \
         open('employees.tmp', 'w', encoding='utf-8') as dst:

        while True:
            name = src.readline()
            if name == '':
                break
            id_num = src.readline()
            dept   = src.readline()

            name   = name.rstrip('\n')
            id_num = id_num.rstrip('\n')
            dept   = dept.rstrip('\n')

            if id_num == emp_id:
                dept = new_dept

            dst.write(f'{name}\n{id_num}\n{dept}\n')

def main():
    replace_department('4587', 'HR')
    replace_department('4588', 'Finance')
    replace_department('4789', 'IT')

if __name__ == '__main__':
    main()