def c_to_f(celsius):
    return celsius * 9.0 / 5.0 + 32

def f_to_c(fahrenheit):
    return (fahrenheit - 32) * 5.0 / 9.0

# Funksion ndihmës (për shembull, për logim të brendshëm)
def _log_conversion(from_unit, to_unit, value):
    # '_' sugjeron që është “privat” për modulin
    print(f"Konvertim nga {from_unit} në {to_unit} për vlerën {value}")
