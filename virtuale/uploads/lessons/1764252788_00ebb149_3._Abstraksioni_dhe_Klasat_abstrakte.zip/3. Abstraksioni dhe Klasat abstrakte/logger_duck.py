def process_items(items, logger):
    logger.info("Po fillojmë përpunimin...")
    for item in items:
        logger.debug(f"Po përpunojmë: {item}")
    logger.info("Përfundoi përpunimi.")

class SimpleLogger:
    def info(self, message):
        print("[INFO]", message)

    def debug(self, message):
        print("[DEBUG]", message)

def main():
    logger = SimpleLogger()
    process_items([1, 2, 3], logger)
