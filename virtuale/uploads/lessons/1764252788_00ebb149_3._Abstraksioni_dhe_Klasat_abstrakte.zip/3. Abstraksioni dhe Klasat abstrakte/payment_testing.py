from abc import ABC, abstractmethod

class PaymentMethod(ABC):
    @abstractmethod
    def pay(self, amount):
        pass

class FakePayment(PaymentMethod):
    def __init__(self):
        self.called = False
        self.paid_amounts = []

    def pay(self, amount):
        print(f"[FAKE] Do të paguanim: {amount}")
        self.called = True
        self.paid_amounts.append(amount)

def process_order(payment_method: PaymentMethod, total_amount):
    print("Po përpunojmë porosinë...")
    payment_method.pay(total_amount)
    print("Porosia u përpunua.\n")

def test_process_order():
    fake = FakePayment()

    process_order(fake, 49.90)

    assert fake.called, "Metoda pay() nuk u thirr!"
    assert fake.paid_amounts == [49.90], "Shuma e paguar nuk është ajo që prisnim!"

    print("Testi kaloi me sukses!")

if __name__ == "__main__":
    test_process_order()
