from abc import ABC, abstractmethod

class PaymentMethod(ABC):
    @abstractmethod
    def pay(self, amount):
        pass

class CreditCardPayment(PaymentMethod):
    def pay(self, amount):
        print(f"Po paguaj {amount} me kartë krediti.")

class CashPayment(PaymentMethod):
    def pay(self, amount):
        print(f"Po paguaj {amount} cash.")

def main():
    # pm = PaymentMethod()  # GABIM: nuk mund të instancohet (ka metoda abstrakte)
    cc = CreditCardPayment()
    cs = CashPayment()

    cc.pay(50)
    cs.pay(20)

if __name__ == '__main__':
    main()
