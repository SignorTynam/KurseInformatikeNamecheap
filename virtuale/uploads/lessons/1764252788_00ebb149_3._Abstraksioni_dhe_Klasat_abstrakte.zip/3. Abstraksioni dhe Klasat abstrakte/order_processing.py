from payments2 import PaymentMethod, CreditCardPayment, PayPalPayment, CashPayment

def process_order(payment_method: PaymentMethod, total_amount):
    print("Po përpunojmë porosinë...")
    payment_method.pay(total_amount)
    print("Porosia u përpunua me sukses.\n")

def main():
    cc   = CreditCardPayment("1234 5678 0000 9999")
    pp   = PayPalPayment("klient@example.com")
    cash = CashPayment()

    process_order(cc,   49.90)
    process_order(pp,   12.50)
    process_order(cash, 5.00)

if __name__ == '__main__':
    main()
