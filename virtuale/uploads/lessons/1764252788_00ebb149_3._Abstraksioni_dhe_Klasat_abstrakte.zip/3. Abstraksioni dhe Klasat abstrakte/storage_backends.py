from abc import ABC, abstractmethod
import json
import os

class StorageBackend(ABC):
    @abstractmethod
    def save(self, data):
        pass

    @abstractmethod
    def load(self):
        pass

class FileStorage(StorageBackend):
    def __init__(self, filename):
        self.__filename = filename

    def save(self, data):
        with open(self.__filename, 'w', encoding='utf-8') as f:
            json.dump(data, f)

    def load(self):
        if not os.path.exists(self.__filename):
            return None
        with open(self.__filename, 'r', encoding='utf-8') as f:
            return json.load(f)

class MemoryStorage(StorageBackend):
    def __init__(self):
        self.__data = None

    def save(self, data):
        self.__data = data

    def load(self):
        return self.__data

class DatabaseStorage(StorageBackend):
    def __init__(self, connection_string):
        self.__connection_string = connection_string
        self.__fake_db = None

    def save(self, data):
        self.__fake_db = data
        print("Po ruajmë në databazë (simuluar)...")

    def load(self):
        print("Po lexojmë nga databaza (simuluar)...")
        return self.__fake_db
