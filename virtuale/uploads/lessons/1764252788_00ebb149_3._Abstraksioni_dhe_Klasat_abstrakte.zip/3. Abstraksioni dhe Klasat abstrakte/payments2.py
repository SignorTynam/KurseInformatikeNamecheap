from abc import ABC, abstractmethod

class PaymentMethod(ABC):
    @abstractmethod
    def pay(self, amount):
        pass

class CreditCardPayment(PaymentMethod):
    def __init__(self, card_number):
        self.__card_number = card_number

    def pay(self, amount):
        print(f"Po paguaj {amount} me kartë krediti ({self.__card_number}).")

class PayPalPayment(PaymentMethod):
    def __init__(self, email):
        self.__email = email

    def pay(self, amount):
        print(f"Po paguaj {amount} përmes PayPal ({self.__email}).")

class CashPayment(PaymentMethod):
    def pay(self, amount):
        print(f"Po paguaj {amount} cash.")
