from abc import ABC, abstractmethod

class PaymentMethod(ABC):
    @abstractmethod
    def pay(self, amount):
        pass

class CreditCardPayment(PaymentMethod):
    def __init__(self, card_number):
        self.__card_number = card_number

    def pay(self, amount):
        print(f"Po paguaj {amount} me kartë krediti ({self.__card_number}).")

class FakePayment(PaymentMethod):
    def __init__(self):
        self.paid = []

    def pay(self, amount):
        print(f"[FAKE] Do të paguanim: {amount}")
        self.paid.append(amount)

def process_order(payment_method: PaymentMethod, total_amount):
    print("Po përpunojmë porosinë...")
    payment_method.pay(total_amount)
    print("Porosia u përpunua.\n")

def demo_real():
    cc = CreditCardPayment("1234 5678 0000 9999")
    process_order(cc, 29.90)

def demo_test():
    fake = FakePayment()
    process_order(fake, 29.90)
    assert fake.paid == [29.90]
    print("Testi (me FakePayment) kaloi!\n")

if __name__ == "__main__":
    demo_real()
    demo_test()
