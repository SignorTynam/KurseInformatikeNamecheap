from collections.abc import Mapping
from collections import defaultdict

def print_scores(scores: Mapping[str, int]) -> None:
    """Shtyp listën e pikëve për çdo student."""
    for name, points in scores.items():
        print(f"{name}: {points} pikë")

def main():
    regular_dict = {"Ardi": 90, "Mira": 85}
    default_dict = defaultdict(int)
    default_dict["Lira"] = 100
    default_dict["Denis"] = 70

    print("Me dict normal:")
    print_scores(regular_dict)

    print("\nMe defaultdict:")
    print_scores(default_dict)
