from shapes import Circle, Rectangle, Triangle

def show_shape_info(shape):
    print('Forma:', type(shape).__name__)
    print('  Sipërfaqja:', shape.area())
    print('  Perimetri:', shape.perimeter())

def main():
    shapes = [ Circle(1), Rectangle(2, 5), Triangle(3, 4, 5) ]
    for s in shapes: show_shape_info(s)

if __name__ == '__main__':
    main()
