from collections.abc import Iterable

class MyRange:
    def __init__(self, start, end):
        self._start = start
        self._end = end

    def __iter__(self):
        current = self._start
        while current < self._end:
            yield current
            current += 1

# I themi ABC-së Iterable: "trajto MyRange si Iterable"
Iterable.register(MyRange)

def main():
    mr = MyRange(0, 3)

    print("Vlerat në MyRange:")
    for x in mr:
        print(x)

    print("A është mr Iterable?", isinstance(mr, Iterable))
