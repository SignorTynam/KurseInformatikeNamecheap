class BankAccount:
    def __init__(self, owner, initial_balance=0):
        self.__owner = owner
        self.__balance = initial_balance

    def deposit(self, amount):
        self.__balance += amount

    def withdraw(self, amount):
        self.__balance -= amount

    def get_balance(self):
        return self.__balance

class Wallet:
    def __init__(self):
        self.__cash = 0

    def deposit(self, amount):
        self.__cash += amount

    def get_balance(self):
        return self.__cash

def main():
    acc = BankAccount('Ardi', 100)
    w   = Wallet()

    pay_salary(acc, 50)
    pay_salary(w, 20)

    print('Gjendja në llogari:', acc.get_balance())
    print('Gjendja në portofol:', w.get_balance())

def pay_salary(account, amount):
    print('Po paguajmë rrogën:', amount)
    account.deposit(amount)

if __name__ == '__main__':
    main()
