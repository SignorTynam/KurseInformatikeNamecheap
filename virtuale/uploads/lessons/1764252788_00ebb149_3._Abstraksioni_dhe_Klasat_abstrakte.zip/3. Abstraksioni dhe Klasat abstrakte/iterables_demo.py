from collections.abc import Iterable

def sum_all(values: Iterable[float]) -> float:
    total = 0.0
    for v in values:
        total += v
    return total

def main():
    nums_list  = [1, 2, 3]
    nums_tuple = (10, 20, 30)
    nums_set   = {0.5, 1.5, 2.5}

    print("Shuma (list): ",  sum_all(nums_list))
    print("Shuma (tuple):",  sum_all(nums_tuple))
    print("Shuma (set):  ",  sum_all(nums_set))

    def gen():
        for i in range(4):
            yield i * 2
    print("Shuma (generator):", sum_all(gen()))

    print("A është string Iterable?", isinstance("hello", Iterable))
