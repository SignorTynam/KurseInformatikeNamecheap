import temperature_utils as tu

def show_report(celsius):
    fahrenheit = tu.c_to_f(celsius)
    print('Temperatura aktuale:')
    print(celsius, 'C')
    print(fahrenheit, 'F')

if __name__ == '__main__':
    show_report(22)
