from bank_account import BankAccount

def main():
    acc = BankAccount('Ardi', 100.0)

    print('Pronari:', acc.get_owner())
    print('Gjendja fillestare:', acc.get_balance())

    acc.deposit(50)
    print('Pas depozitimit:', acc.get_balance())

    acc.withdraw(80)
    print('Pas tërheqjes:', acc.get_balance())

if __name__ == '__main__':
    main()
