class BankAccount:
    def __init__(self, owner, initial_balance=0.0):
        self.__owner = owner
        self.__balance = float(initial_balance)

    # --- Interface publik ---
    def deposit(self, amount):
        if amount <= 0: raise ValueError('Shuma duhet të jetë pozitive.')
        self.__balance += amount

    def withdraw(self, amount):
        if amount <= 0: raise ValueError('Shuma duhet të jetë pozitive.')
        if amount > self.__balance: raise ValueError('Fondet nuk mjaftojnë.')
        self.__balance -= amount

    def get_balance(self):
        return self.__balance

    def get_owner(self):
        return self.__owner
