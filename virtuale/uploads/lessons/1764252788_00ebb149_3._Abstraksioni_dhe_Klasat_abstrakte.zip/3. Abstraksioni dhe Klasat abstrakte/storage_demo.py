from storage_backends import FileStorage, MemoryStorage, DatabaseStorage, StorageBackend

def save_user_profile(storage: StorageBackend, profile):
    print("Po ruajmë profilin e përdoruesit...")
    storage.save(profile)
    print("U ruajt.\n")

def load_user_profile(storage: StorageBackend):
    print("Po lexojmë profilin e përdoruesit...")
    profile = storage.load()
    print("Profili:", profile)
    print()

def main():
    profile_data = {"name": "Ardi", "age": 25}

    file_storage = FileStorage("profile.json")
    mem_storage  = MemoryStorage()
    db_storage   = DatabaseStorage("db://connection-string")

    for backend in (file_storage, mem_storage, db_storage):
        save_user_profile(backend, profile_data)
        load_user_profile(backend)

if __name__ == '__main__':
    main()
