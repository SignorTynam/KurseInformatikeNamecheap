﻿# Get the user's starting weight.
weight = int(input('What is your starting weight? '))

# Display the weight loss table.
for month in range(1, 6):
    weight = weight - 4
    print(f'At the end of month {month} your weight will be {weight} lbs.')
