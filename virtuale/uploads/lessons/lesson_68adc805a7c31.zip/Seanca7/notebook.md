# Leksioni 7: Ushtrime

Ky notebook përmbledh të gjitha ushtrimet dhe kërkesat që kemi zhvilluar në leksionin 7.

### Ushtrimi 1

Shkruani një program që pranon numra pozitivë nga përdoruesi dhe llogarit shumën e tyre. Programi ndalon kur përdoruesi jep një numër negativ.

```python
# Declare variables for the number, and the
# total.
number = 1.0    # Initialize for while loop
total = 0.0

# Continue adding numbers while they are positive.
while number > 0:
    number = float(input('Enter a positive number (negative to quit): '))

    # Check that number is positive so as
    # not to change value of the total.
    if number > 0:
        total += number         # total = total + number

# Display total.
print (f'Total = {total:.2f}') 
```

### Ushtrimi 2

Shkruani një program që llogarit ngritjen e nivelit të detit çdo vit për 25 vite, duke supozuar një ngritje prej 1.6 mm në vit.

```python
# Programming Exercise 4-9

# Constant for the rise per year.
RISE_PER_YEAR = 1.6

# Declare a variable to store the rise.
rise = 0.0

# Calculate and print value for the rise each year.
print ('Year\t\tRise (in millimeters)')
print ('------------------------------------------')

for year in range(25):
    rise += RISE_PER_YEAR
    print (f'{year + 1}\t\t{rise:.2f}')
```

### Ushtrimi 3

Shkruani një program që llogarit tarifën e shkollës për 5 vite, duke supozuar një rritje prej 3% çdo vit dhe një shumë fillestare prej 8000.

```python
# Programming Exercise 4-10

# Constants for the increase in tuition per year,
# and the starting tuition amount.
INCREASE_PER_YEAR = 0.03
STARTING_AMOUNT = 8000.0

# Declare a variable to store the tuition.
tuition = STARTING_AMOUNT

# Calculate and print amount of increase each year.
print ('Year\t Projected Tuition (per Semester)')
print ('------------------------------------------')

for year in range(5):
    tuition += (tuition * INCREASE_PER_YEAR)            # tuition = tuition + (tuition * INCREASE_PER_YEAR)
    print (f'{year + 1}\t${tuition:,.2f}')
```

### Ushtrimi 4

Shkruani një program që tregon humbjen e peshës për çdo muaj, duke supozuar që përdoruesi humbet 4 lbs çdo muaj për 5 muaj.

```python
# Get the user's starting weight.
weight = int(input('What is your starting weight? '))

# Display the weight loss table.
for month in range(1, 6):
    weight = weight - 4
    print(f'At the end of month {month} your weight will be {weight} lbs.')
```

### Ushtrimi 5

Shkruani një program që merr një numër të plotë jo-negativ nga përdoruesi dhe llogarit faktorialin e tij.

```python
# Inititalize number to zero.
number = 0 

# Get a valid number from the user.
while number <= 0:
    number = int(input('Enter a nonnegative integer: '))

# Initialize the accumulator variable.
factoral = 1

# Calculate the factoral of the number.
for factor in range(1, number + 1):
    factoral *= factor

# Display the factoral of the number.
print(f'The factoral of {number} is {factoral:,d}')
```

### Ushtrimi 6

Shkruani një program që llogarit popullsinë e organizmave për një numër të caktuar ditësh, duke marrë si input numrin fillestar, rritjen mesatare ditore dhe numrin e ditëve.

```python
# Programming Exercise 4-12

num = 0     # The starting number of organisms
avg = 0.0   # The average daily increase
days = 0    # The number of days to multiply

# Get a valid value for the starting number of
# organisms from the user.
while num <= 0:
    num = int(input('Starting number of organisms: '))

# Get a valid value for the average daily
# increase from the user.
while avg <= 0:
    avg = float(input('Average daily increase: '))

# Get a valid value for the number of days
# to multiply from the user.
while days <= 0:
    days = int(input('Number of days to multiply: '))

# Determine if the average daily increase was
# input as a whole number; if so, divide by
# 100 to format the value as a percentage.
if avg >= 1.0:
    avg /= 100.0

# Calculate and print amount of increase each day.
print ('Day Approximate\t\t Population')
print ('-----------------------------------')

for day in range(days):
    # Apply the increase after the first day.
    if (day > 0):
        num += (num * avg)
    print ((day + 1), '\t\t\t', num)
```

### Ushtrimi 7

Shkruani një program që llogarit shumën e numrave nga 1 deri në 10.

```python
shuma = 0

for i in range(1,11):
    shuma += i

print("Shuma nga 1 deri ne 10 eshte", shuma)
```