shuma = 0

for i in range(1,11):
    shuma += i

print("Shuma nga 1 deri ne 10 eshte", shuma)
 