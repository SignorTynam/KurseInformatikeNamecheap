def main():
    n = int(input('Sa punonjës ka Megan? '))
    hours = [0.0] * n
    for i in range(n):
        hours[i] = float(input(f'Orët e punës nga punonjësi {i + 1}: '))
    rate = float(input('Paga-orare: '))
    for i, h in enumerate(hours, start=1):
        print(f'Paga bruto për punonjësin {i}: ${h * rate:,.2f}')

if __name__ == '__main__':
    main()