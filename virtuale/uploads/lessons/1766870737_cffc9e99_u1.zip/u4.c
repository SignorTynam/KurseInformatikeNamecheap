#include <stdio.h>

int main() {

    int mosha, price;

    scanf("%d", &mosha);

    if (mosha < 12) {
        price = 5;
    } else if (mosha <= 25) {
        price = 7;
    } else if (mosha <= 64) {
        price = 10;
    } else {
        price = 6;
    }

    printf("Cmimi i bilete eshte %d euro", price);

    return 0;
}