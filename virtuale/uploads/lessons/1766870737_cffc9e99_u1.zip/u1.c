#include <stdio.h>

int main() {

    float t;

    printf("Vendos t: ");
    scanf("%f", &t);

    if (t < 0.0f) {
        printf("Ngrice\n");
    } else if (t <= 20.0f) {
        printf("Ftohte\n");
    } else if (t <= 30.0f) {
        printf("Ngrohte\n");
    } else {
        printf("Shume nxehte!\n");
    }

    return 0;
}