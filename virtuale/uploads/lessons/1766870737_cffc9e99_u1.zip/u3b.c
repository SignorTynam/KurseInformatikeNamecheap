#include <stdio.h>

int main() {

    int pass;

    scanf("%d", &pass);

    if (pass == 1234) {
        printf("Fjalekalimi eshte i sakte");
    } else if (pass != 1234 && pass < 0) {
        printf("Fjalekalimi eshte i gabuar");
        printf("Provo me vone!!!");
    } else {
        printf("Fjalekalimi eshte i gabuar");
    }

    return 0;
}