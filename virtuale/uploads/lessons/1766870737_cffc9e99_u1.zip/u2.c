#include <stdio.h>

int main() {

    int a, b, c;
    int max;


    scanf("%d %d %d", &a, &b, &c);

    if (a >= b && a >= c) {
        max = a;
    } else if (b >= c) {
        max = b;
    } else {
        max = c;
    }

    printf("Numri me i madh eshte %d", max);

    return 0;
}