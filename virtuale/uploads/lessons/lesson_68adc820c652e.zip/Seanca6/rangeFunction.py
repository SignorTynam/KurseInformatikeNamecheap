# FUNKSIONI RANGE
# Funksioni range() kthen nje seri numerash te quajtur iterable
# Nje iterable eshte nje objekt qe mund te iterohet (p.sh. me ciklin for) dhe shume e ngjashme me nje liste
# Krijon nje sekuence vlerash qe mund te iterohen duke perdorur ciklin for

# range(x) -> kthen [0, 1, 2, ..., x-1] nese x eshte numer i plote pozitive, [EMPTY] nese x eshte numer i plote negativ ose 0
# range(5) -> [0, 1, 2, 3, 4]
# range(-7) -> []

for i in range(5):
    print(i, end=' ')
print()

# range(x, y) -> kthen [x, x+1, x+2, ..., y-1] nese x dhe y jane numra te plote dhe x < y, [EMPTY] ne te kundert
# range(2, 5) -> [2, 3, 4]
# range(7, 1) -> []

for i in range(2, 5):
    print(i, end=' ')
print()

# range(x, y, z) -> kthen [x, x+z, x+2z, ..., x+nz] nese x, y, dhe z jane numra te plote, z eshte pozitiv, dhe x < y
# range(1, 10, 2) -> [1, 3, 5, 7, 9]    
# range(10, 1, 2) -> []
# range(1, 20, 3) -> [1, 4, 7, 10, 13, 16, 19]

for i in range(1, 10, 2):
    print(i, end=' ')
print()

# range(10, 0, -1) -> [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
for i in range(10, 0, -1):
    print(i, end=' ')