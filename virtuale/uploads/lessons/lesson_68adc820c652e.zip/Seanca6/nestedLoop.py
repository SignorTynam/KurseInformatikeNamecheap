# Nje nested loop eshte nje cikli qe permban nje cikli tjeter brenda tij.
# Nested loops perdoren kur duhet te ekzekutohet nje cikli brenda nje cikli.
# Nested loops mund te kene shume nivele.
# Nested loops mund te jene cikle FOR ose cikle WHILE.
# Nested loops mund te jene cikle te ndryshem, psh nje cikel FOR brenda nje cikli WHILE.'

for second in range(60):
    print(second)

"""Output:
0
1
2
3
4
5
6
7
8
...
"""

for minutes in range(60):
    for seconds in range(60):
        print(minutes, seconds)

"""Output:"
0 0
0 1
0 2
0 3
0 4
0 5
0 6
0 7
0 8
...
0 59
1 0
1 1
1 2
1 3
1 4
1 5
1 6
1 7
1 8
...
1 59
2 0
2 1
...
"""

for hours in range(24):
    for minutes in range(60):
        for seconds in range(60):
            print(hours, minutes, seconds)

"""Output:
0 0 0
0 0 1
0 0 2
0 0 3
0 0 4
...
0 0 59
0 1 0
0 1 1
0 1 2
0 1 3
0 1 4
...
0 1 59
0 2 0
0 2 1
...
0 59 59
1 0 0
1 0 1
...
1 59 59
2 0 0
2 0 1
...
"""