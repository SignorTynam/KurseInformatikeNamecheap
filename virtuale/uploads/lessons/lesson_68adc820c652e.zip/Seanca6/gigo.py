# GARBAGE IN, GARBAGE OUT (GIGO)

hourse = int(input("Enter the number of hours worked: "))
# Ne rastin e mesiperme nese perdoruesi vendos nje vlere qe quhet Bad Value e cila ne rastin aktual
# mund te jete nje vlere negative, programi do te ekzekutohet por do te jape nje vlere negative per Gross Pay.
# Hours nuk duhet te pranoje vlere negative.

rate = float(input("Enter the hourly rate: "))
# I njejti shpjegim si me lart. Rate nuk duhet te pranoje vlere negative.

gross_pay = hourse * rate
# Nese perdoruesi vendos vlere negative per Hours ose Rate, Gross Pay do te jete negative gje qe nuk
# eshte e mundur ne realitet. Per te shmangur kete problem mund te perdorim nje ciklin WHILE per te
# siguruar qe vlerat e vendosura nga perdoruesi jane te sakta. Kjo quhet INPUT VALIDATION.

print(f"Gross pay: {gross_pay:.2f}")