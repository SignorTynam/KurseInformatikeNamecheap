# Leksioni 6 - Strukturat ciklike në Python

Këtu keni një leksion gjithëpërfshirës në Python mbi strukturat e përsëritjes, bazuar në slide‑et. Ky leksion mbulon konceptet kryesore të cikleve, nga ciklet e kontrolluara nga kushti (while loop) te ato të kontrolluara nga numri (for loop), duke përfshirë shembuj të ndryshëm që mund të eksperimentoni vetë. Në vijim, shpjegojmë konceptet me kode të dokumentuara.

## 1. Hyrje në Strukturat e Përsëritjes

Në shumë raste, programet kanë nevojë të kryejnë të njëjtat instruksione disa herë. Në vend që të keni kopjuar e pastër të një blloku kodi, përdorimi i cikleve ndihmon në:

- **Uljen e përsëritjes së kodit**: një bllok kodi ekzekutohet shumë herë.
- **Përmirësimin e mirëmbajtjes**: ndryshimet bëhen vetëm në një vend.
- **Zhvillimin e logjikës më të qartë**: përsëritja shpjegohet me struktura të formës së cikleve.

Këto struktura përfshijnë:

- **Ciklet me kusht** (si `while`)
- **Ciklet të kontrolluara nga numri** (si `for`)
- **Ciklet e ndërritura** dhe të tjera që përdoren për gjëra të ndryshme (plot me shembuj më poshtë).

## 2. Cikli **`while`** – Struktura me Kusht

### Shpjegim  

Cikli **`while`** vazhdon të ekzekutohet derisa kushti i dhënë të bëhet i pavërtetë. Kjo lloj cikli është i përshtatshëm kur nuk dini paraparë sa herë duhet të përsëritet kodi.

### Sintaksa

```python
while kushti:
    # blloku i kodit që duhet të përsëritet
```

### Shembull: Numërimi nga 1 në 5

```python
n = 1
while n <= 5:
    print("Numri:", n)
    n += 1  # rrit vlerën e n me 1 për çdo iteracion
```

### Pika të rëndësishme

- Duhet të siguroheni që brenda ciklit ekziston ndonjë mekanizëm që shndërron kushtin në të pavërtetë, përndryshe cikli do të bëhet i pafund.

## 3. Cikli **`for`** – Struktura e Kontrolluar nga Numri

### Shpjegim  

Cikli **`for`** përdoret për të kaluar nëpër një sekuencë (listë, vargje, etj.) ose për ∞përdorimin e funksionit të integruar **`range`** për numërimin e iteracioneve. Kjo strukturë thjeshton kodin kur dini saktë numrin e iteracioneve.

### Sintaksa

```python
for variabël in iterable:
    # blloku i kodit që ekzekutohet për çdo vlerë
```

### Shembull: Numërimi me **`range`**

```python
for i in range(1, 6):  # i merr vlerat nga 1 deri në 5
    print("Numri:", i)
```

### Funksioni **`range`**

- **`range(10)`** – gjeneron numrat nga 0 deri në 9.
- **`range(1, 11)`** – gjeneron numrat nga 1 deri në 10 (vlera përfundimtare nuk përfshihet).
- **`range(0, 10, 2)`** – gjeneron numrat 0, 2, 4, 6, 8 (tretimi përcakton hapin midis numrave). [^1^]

## 4. Kalkulimi i një Shume të Vazhdueshme

Shpesh nga ne kemi nevojë të llogarisim totalin e një sekuence numrash. Për ta bërë këtë, përdorim një variabël akumulatore që shtohet me secilin numër gjatë ciklit.

### Shembull: Sumimi i një liste numrash

```python
shuma = 0
numrat = [1, 2, 3, 4, 5]

for num in numrat:
    shuma += num  # një ekuivalent i shkurtër për: shuma = shuma + num
print("Shuma e numrave:", shuma)
```

### Shpjegim

- Variabli **`shuma`** ruan rezultatin përfundimtar që përditësohet në çdo iteracion. [^1^]

## 5. Operatorët e Dhënës Augmentuese

Për shumë herë, operacionet aritmetike për një variabël duhet të ruhen direkt në të. Operatorët augumentues, si **`+=`**, **`-=`**, **`*=`**, etj., e bëjnë atë më të lehtë dhe më të pastër.

### Shembull

```python
x = 5
x += 3   # i barabartë me: x = x + 3 -> rezultat: 8
print("Rezultati i x:", x)
```

Ky mekanizëm është i dobishëm kur kryeni modifikime të përsëritura në një variabël gjatë një cikli. [^1^]

## 6. Vlera Sentinel

Një **sentinel** është një vlerë e veçantë që shënon fundin e një sekuence të të dhënave. Kjo metodë përdoret shpesh në hyjet e përdoruesit kur shkruhet një cikël që duhet të ndalohet në mënyrë elektronike kur futet një vlerë e caktuar.

### Shembull: Përdorimi i Sentinel për dalje

```python
while True:
    data = input("Shkruaj diçka (q për të dalë): ")
    if data.lower() == 'q':
        break  # ndërprer ciklin nëse përdoruesi shkruan "q"
    print("Inputi yt:", data)
```

Ky shembull mban ciklin aktiv derisa përdoruesi të futë 'q'. [^1^]

## 7. Ciklet për Validimin e Hyrjes (Input Validation Loops)

Kur kërkoni të siguroheni që përdoruesi ka futur të dhëna të vlefshme, ciklet e validimit u lejojnë programit të kontrollojë dhe të kërkojë përsëri input-in derisa të plotësohet kushti i caktuar.

### Shembull: Kërkimi i një numri pozitiv

```python
numri = int(input("Shkruaj një numër pozitiv: "))
while numri <= 0:
    print("Gabim! Numri duhet të jetë pozitiv.")
    numri = int(input("Përsëri, shkruaj një numër pozitiv: "))
print("Numri i futur është:", numri)
```

Ky shembull rikërkon kërkesën derisa që përdoruesi të fusë një numër pozitiv. [^1^]

## 8. Ciklet e mbivendosura (Nested Loops)

Një cikël i brendshëm brenda një cikli të jashtëm përdoret kur duhet të përpunohen të dhëna në një strukturë dy-dimensionale (si matricat) ose në raste ku një operacion brenda një operacioni kryhet shumë herë.

### Shembull: Printimi i koordinatave në një matricë 3×3

```python
for i in range(1, 4):
    for j in range(1, 4):
        print(f"({i}, {j})", end=" ")
    print()  # për të kaluar në një linjë të re
```

Në këtë shembull, për çdo rresht (variabli **`i`**), cikli i brendshëm (variabli **`j`**) shtyp çdo çift koordinatash. [^1^]

## 9. Turtle Graphics – Përdorimi i Cikleve për Vizatim

Biblioteka **`turtle`** në Python lejon krijimin e grafikës bazuar në komandat për vizatim. Duke përdorur ciklet, mund të vizatoni forma gjeometrike dhe dizajne komplekse.

### Shembull 1: Vizato një katror

```python
import turtle

for _ in range(4):
    turtle.forward(100)  # ec me 100 pikselë
    turtle.right(90)     # kthyer 90 gradë
turtle.done()
```

### Shembull 2: Vizato një oktagon (8-anë)

```python
import turtle

for _ in range(8):
    turtle.forward(100)
    turtle.right(45)  # 360 / 8 = 45 gradë
turtle.done()
```

### Shembull 3: Dizajn me rrethuj të ndërthurur

```python
import turtle

NUM_CIRCLES = 36    # numri i rrethujve
RADIUS = 100        # rrezja e secilit rreth
ANGLE = 10          # këndi i kthimit midis rrethujve

for _ in range(NUM_CIRCLES):
    turtle.circle(RADIUS)
    turtle.left(ANGLE)
turtle.done()
```

Këto shembuj tregojnë se si përdorimi i cikleve bën të mundur krijimin e dizajneve të ndryshme me pak kod. [^1^]

## Përfundim dhe Ide Shtesë

Në këtë leksion kemi mbuluar:

- **Strukturat e përsëritjes**: Si ciklet `while` (kushtore) ashtu edhe `for` (numërore).  
- **Funksionin `range`**: Për të gjeneruar sekuenca numrash me një, dy ose tre parametra.  
- **Kalkulimin e shumave të vazhdueshme** me ndihmën e variablave akumulatorë dhe operatorëve të dhënës augmentuese.  
- **Përdorimin e vlerave sentinel** për të përcaktuar fundin e një sekuence.  
- **Validimin e hyrjes**: Sigurimi që përdoruesi fut të dhëna të vlefshme.  
- **Ciklet e ndërritura**: Përshtatshme për trajtimin e të dhënave në struktura më komplekse.  
- **Turtle Graphics**: Si të përdorni ciklet për të vizatuar forma dhe dizajne kreative.
