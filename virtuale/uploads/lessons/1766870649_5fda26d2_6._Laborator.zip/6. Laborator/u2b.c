#include <stdio.h>
#include <stdbool.h>
int main() {

    int a, b, c;

    printf("Vendos tre numra te plote: ");

    if (scanf("%d %d %d", &a, &b, &c) != 3) {
        printf("Input i pavlefshëm.\n");
        return 1;
    }


    bool aLargest = (a >= b) && (a >= c);
    bool bLargest = (b >= a) && (b >= c);
    bool cLargest = (c >= a) && (c >= b);

    bool aSmallest = (a <= b) && (a <= c);
    bool bSmallest = (b <= a) && (b <= c);
    bool cSmallest = (c <= a) && (c <= b);

    int maxv = aLargest ? a : (bLargest ? b : c);
    int minv = aSmallest ? a : (bSmallest ? b : c);

    printf("Numri maksimal: %d\n", maxv);
    printf("Numri minimal: %d\n", minv);

    return 0;
}