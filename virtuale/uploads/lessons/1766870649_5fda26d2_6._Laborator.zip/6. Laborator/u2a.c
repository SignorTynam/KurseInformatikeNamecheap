#include <stdio.h>
int main() {

    int a, b, c;

    printf("Vendos tre numra te plote: ");

    if (scanf("%d %d %d", &a, &b, &c) != 3) {
        printf("Input i pavlefshëm.\n");
        return 1;
    }

    int maxv = (a > b) ? a : b;
    maxv = (c > maxv) ? c : maxv;

    int minv = (a < b) ? a : b;
    minv = (c < minv) ? c : minv;

    printf("Numri maksimal: %d\n", maxv);
    printf("Numri minimal: %d\n", minv);

    return 0;
}