#include <stdio.h>

int main(void) {
    long long n;
    long long rev = 0;
    int sign = 1;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) {
        printf("Gabim: input i pavlefshem!\n");
        return 0;
    }

    if (n < 0) {
        sign = -1;
        n = -n;
    }

    /* do-while: ekzekutohet te pakten nje here (p.sh. kur n=0) */
    do {
        long long digit = n % 10;
        rev = rev * 10 + digit;
        n /= 10;
    } while (n > 0);

    rev *= sign;
    printf("Reversed number: %lld\n", rev);

    return 0;
