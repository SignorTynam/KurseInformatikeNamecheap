#include <stdio.h>

int main(void) {
    double a, b, c;

    printf("Enter three sides: ");
    if (scanf("%lf %lf %lf", &a, &b, &c) != 3) {
        printf("Gabim: input i pavlefshem!\n");
        return 0;
    }

    /* Validim: brinje pozitive */
    if (a <= 0 || b <= 0 || c <= 0) {
        printf("Gabim: brinje te pavlefshme!\n");
        return 0;
    }

    /* Validim: triangle inequality */
    if (a + b <= c || a + c <= b || b + c <= a) {
        printf("Gabim: nuk formohet trekendesh!\n");
        return 0;
    }

    if (a == b && b == c) {
        printf("This is an equilateral triangle.\n");
    } else if (a == b || a == c || b == c) {
        printf("This is an isosceles triangle.\n");
    } else {
        printf("This is a scalene triangle.\n");
    }

    return 0;
}
