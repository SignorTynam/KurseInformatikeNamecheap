#include <stdio.h>

int main(void) {
    double x, y, res;
    int op;

    printf("Jep x dhe y: ");
    if (scanf("%lf %lf", &x, &y) != 2) {
        printf("Gabim: input i pavlefshem!\n");
        return 0;
    }

    printf("Zgjidh veprimin (1=+, 2=-, 3=*, 4=/): ");
    if (scanf("%d", &op) != 1) {
        printf("Gabim: zgjedhje e pavlefshme!\n");
        return 0;
    }

    switch (op) {
        case 1:
            res = x + y;
            printf("Rezultati: %.6f\n", res);
            break;

        case 2:
            res = x - y;
            printf("Rezultati: %.6f\n", res);
            break;

        case 3:
            res = x * y;
            printf("Rezultati: %.6f\n", res);
            break;

        case 4:
            if (y == 0.0) {
                printf("Gabim: ndarja me zero!\n");
                return 0;
            }
            res = x / y;
            printf("Rezultati: %.6f\n", res);
            break;

        default:
            printf("Gabim: zgjedhje e pavlefshme! (Duhet 1..4)\n");
            return 0;
    }

    return 0;
}
