#include <stdio.h>

int main(void) {
    double x, sum = 0.0;
    int count = 0;
    char ans;

    printf("Deshiron te fusësh nje numer? (y/n): ");
    if (scanf(" %c", &ans) != 1) {
        printf("Gabim: input i pavlefshem!\n");
        return 0;
    }

    while (ans == 'y' || ans == 'Y') {
        printf("Jep numrin: ");
        if (scanf("%lf", &x) != 1) {
            printf("Gabim: numer i pavlefshem!\n");
            return 0;
        }

        sum += x;
        count++;

        printf("Deshiron te fusësh nje numer tjeter? (y/n): ");
        if (scanf(" %c", &ans) != 1) {
            printf("Gabim: input i pavlefshem!\n");
            return 0;
        }
    }

    if (count == 0) {
        printf("S'ka te dhena.\n");
    } else {
        double avg = sum / count;
        printf("Numri i elementeve: %d\n", count);
        printf("Mesatarja: %.2f\n", avg);
    }

    return 0;
}
