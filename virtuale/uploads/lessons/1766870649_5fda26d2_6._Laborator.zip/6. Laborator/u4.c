#include <stdio.h>
#include <limits.h>
int main() {
    int n;
    long long prodOdd = 1;
    long long sumEven = 0;

    printf("Vendos nje numer te plote pozitiv: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Input i pavlefshëm.\n");
        return -1;
    }

    for (int i = 1; i <=n; i++) {
        if (i % 2 == 0) {
            sumEven += i;
        } else {
            if (prodOdd > LLONG_MAX / i) {
                printf("Shuma e numrave cift tejkalon kufirin e vlefshmërisë.\n");
                break;
            }
            prodOdd *= i;
        }
    }

    printf("Prodhimi i numrave tek: %lld\n", prodOdd);
    printf("Shuma e numrave cift: %lld\n", sumEven);

    return 0;
}