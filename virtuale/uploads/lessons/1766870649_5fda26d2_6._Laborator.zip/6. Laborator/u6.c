#include <stdio.h>

int main(void) {
    double x;
    double sum = 0.0;
    double max = 0.0;
    int count = 0;

    printf("Jep numra (ndalo me -1):\n");

    /* Leximi i pare */
    if (scanf("%lf", &x) != 1) {
        printf("Gabim: input i pavlefshem!\n");
        return 0;
    }

    while (x != -1) {
        if (count == 0) {
            max = x;               /* inicializim i maksimumit */
        } else if (x > max) {
            max = x;
        }

        sum += x;
        count++;

        if (scanf("%lf", &x) != 1) {
            printf("Gabim: input i pavlefshem!\n");
            return 0;
        }
    }

    if (count == 0) {
        printf("S'ka te dhena.\n");
    } else {
        double avg = sum / count;
        printf("Numri i elementeve: %d\n", count);
        printf("Mesatarja: %.2f\n", avg);
        printf("Maksimumi: %.2f\n", max);
    }

    return 0;
}
