#include <stdio.h>
#include <string.h>

int main(void) {
    int n;

    printf("Enter total number of salespeople: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Gabim: n i pavlefshem!\n");
        return 0;
    }

    char bestName[128] = "";
    double bestSalary = -1.0;

    for (int i = 1; i <= n; i++) {
        char name[128];
        double sale, gross = 0.0;

        printf("Enter the name: ");
        if (scanf("%127s", name) != 1) {
            printf("Gabim: emer i pavlefshem!\n");
            return 0;
        }

        printf("Enter sales in dollars (end with -1):\n");

        /* Lexo shitjet derisa te vijë -1 */
        if (scanf("%lf", &sale) != 1) {
            printf("Gabim: shitje e pavlefshme!\n");
            return 0;
        }

        while (sale >= 0.0) {
            gross += sale;

            if (scanf("%lf", &sale) != 1) {
                printf("Gabim: shitje e pavlefshme!\n");
                return 0;
            }
        }

        /* Llogarit paga */
        double salary = 200.0 + 0.09 * gross;
        printf("Salary for %s is: $%.2f\n", name, salary);

        /* Gjej maksimumin */
        if (salary > bestSalary) {
            bestSalary = salary;
            strcpy(bestName, name);
        }
    }

    printf("The salesperson with the highest salary\n");
    printf("is: %s $%.2f.\n", bestName, bestSalary);

    return 0;
}
