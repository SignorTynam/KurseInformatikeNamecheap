#include <stdio.h>

int main() {

    int p;
    char nota;

    printf("Vendos piken e studentit: ");

    if (scanf("%d", &p) != 1) {
        printf("Vlere e pavlefshme per piken.\n");
        return 1;
    }

    if (p < 0 || p > 100) {
        printf("Pika duhet te jete midis 0 dhe 100.\n");
        return 1;
    }

    if (p >= 90) {
        nota = 'A';
    } else if (p >= 80) {
        nota = 'B';
    } else if (p >= 70) {
        nota = 'C';
    } else if (p >= 60) {
        nota = 'D';
    } else {
        nota = 'F';
    }

    return 0;
}