#include <stdio.h>

int main(void) {
    long long n, temp, rev = 0;
    long long original;

    printf("Enter an integer: ");
    if (scanf("%lld", &n) != 1) {
        printf("Gabim: input i pavlefshem!\n");
        return 0;
    }

    /* Trajtim i thjeshte: numrat negative nuk i konsiderojme palindrome */
    if (n < 0) {
        printf("Not a palindrome.\n");
        return 0;
    }

    original = n;
    temp = n;

    while (temp > 0) {
        long long digit = temp % 10;
        rev = rev * 10 + digit;
        temp /= 10;
    }

    /* Rast i veçantë: n = 0 */
    if (original == 0) {
        rev = 0;
    }

    if (rev == original) {
        printf("Palindrome.\n");
    } else {
        printf("Not a palindrome.\n");
    }

    return 0;
}
