#include <stdio.h>

int main(void) {
    int n;
    char ch;

    /* Lexo n dhe ch (me hapësirë para %c për të kapërcyer newline/space) */
    printf("Enter n and ch: ");
    if (scanf("%d %c", &n, &ch) != 2) {
        printf("Gabim: input i pavlefshem!\n");
        return 0;
    }

    if (n <= 0) {
        printf("Gabim: n duhet te jete > 0\n");
        return 0;
    }

    for (int row = n; row >= 1; row--) {
        int indent = 2 * (n - row);

        /* hapësirat në fillim për ta zhvendosur djathtas */
        for (int s = 0; s < indent; s++) {
            printf(" ");
        }

        /* shtyp row karaktere, secili i ndjekur nga nje hapësirë */
        for (int k = 1; k <= row; k++) {
            printf("%c ", ch);
        }

        printf("\n");
    }

    return 0;
}
