# Programming Exercise 11-2

import emp2 as emp

def main():
    # Local variables
    super_name= ''
    super_id = ''
    super_salary = 0.0
    super_bonus = 0.0
    
    # Get data attributes.
    super_name = input('Enter the name: ')
    super_id = input('Enter the ID number: ')
    super_salary = float(input('Enter the annual salary: '))
    super_bonus = float(input('Enter the bonus: '))

    # Create an instance of ShiftSupervisor.
    supervisor = emp.ShiftSupervisor(super_name, super_id,
                                     super_salary, super_bonus)

    # Display information.
    print ('Shift supervisor worker information: ')
    print (f'Name: {supervisor.get_name()}')
    print (f'ID number: {supervisor.get_id_number()}')
    print (f'Annual Salary: ${supervisor.get_salary():,.2f}')
    print (f'Annual Production Bonus: ${supervisor.get_bonus():,.2f}')

# Call the main function.
if __name__ == '__main__':
    main()