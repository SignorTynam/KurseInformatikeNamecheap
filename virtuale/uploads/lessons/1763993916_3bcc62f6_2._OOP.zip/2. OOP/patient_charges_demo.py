import procedure
import patient

def main():
    procedure_1 = procedure.Procedure('Physical Exam', '8-24-2019',
                                      'Dr. Irvine', 250.0)
    procedure_2 = procedure.Procedure('X-ray', '8-24-2019',
                                      'Dr. Jamison', 500.0)
    procedure_3 = procedure.Procedure('Blood Test', '8-24-2019',
                                      'Dr. Smith', 200.0)

    pat = patient.Patient('James', 'Edward', 'Jones', '123 Main Street',
                          'Billings', 'Montana', '59000', '406-555-1212',
                          'Jenny Jones', '406-555-1213')

    print(pat)
    print(procedure_1)
    print(procedure_2)
    print(procedure_3)

# Call the main function.
if __name__ == '__main__':
    main()