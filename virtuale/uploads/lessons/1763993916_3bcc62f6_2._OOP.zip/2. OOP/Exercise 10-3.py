# Programming Exercise 10-3

import info

def main():
    # Create three instances of Information
    my_info = info.Information('John Doe','111 My Street',
                               22, '555-555-1281')
    mom_info = info.Information('Mom', '222 Any Street',
                                52, '555-555-1234')
    sister_info = info.Information('Jane Doe', '333 Her Street',
                                   20, '555-555-4444')

    print('My information:')
    display_info(my_info)
    print()
    print("Mom's information:")
    display_info(mom_info)
    print()
    print ("Sis's infomation:")
    display_info(sister_info)

def display_info(info):
    print(f'Name: {info.get_name()}')
    print(f'Address: {info.get_address()}')
    print(f'Age: {info.get_age()}')
    print(f'Phone Number: {info.get_phone_number()}')

# Call the main function.
if __name__ == '__main__':
    main()