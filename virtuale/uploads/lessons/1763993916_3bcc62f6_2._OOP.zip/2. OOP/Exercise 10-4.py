# Programming Exercise 10-4

import emp

def main():
    # Create three instances of Employee
    emp1 = emp.Employee('Susan Meyers', '47899',
                        'Accounting', 'Vice President')
    emp2 = emp.Employee('Mark Jones', '39119',
                        'IT', 'Programmer')
    emp3 = emp.Employee('Joy Rogers', '81774',
                        'Manufacturing', 'Engineer')

    print('Employee 1:')
    print(emp1)
    print()
    print('Employee 2:')
    print(emp2)
    print()
    print('Employee 3:')
    print(emp3)

# Call the main function.
if __name__ == '__main__':
    main()