# Programming Exercise 10-6

import emp
import pickle

# Global constants for menu choices
LOOK_UP = 1
ADD = 2
CHANGE = 3
DELETE = 4
QUIT = 5

# Global constant for filename
FILENAME = 'employees.dat'

# main function
def main():

    # Get employee dictionary.
    employees = load_employees()

    # Initialize variable for user choice.
    choice = 0

    # Process user requests until user quits.
    while choice != QUIT:

        choice = get_user_choice()

        if choice== LOOK_UP:
            look_up(employees)
        elif choice == ADD:
            add(employees)
        elif choice == CHANGE:
            change(employees)
        elif choice == DELETE:
            delete(employees)

    # Pickle the resulting dictionary.
    save_employees(employees)
    
def load_employees():
    try:
        # Open the file.
        input_file = open(FILENAME, 'rb')

        # Unpickle the dictionary.
        employee_dict = pickle.load(input_file)

        # Close the file.
        input_file.close()
    except IOError:
        # Could not open file.
        # Create empty dictionary.
        employee_dict = {}

    return employee_dict

def get_user_choice():

    # Display menu, get user choice, and validate it.
    print()
    print('Menu')
    print('----------------------------------------')
    print('1. Look up an employee')
    print('2. Add a new employee')
    print('3. Change an existing employee')
    print('4. Delete an employee')
    print('5. Quit the program')
    print()

    choice = int(input('Enter your choice: '))

    # Validate the choice.
    while choice < LOOK_UP or choice > QUIT:
        choice = int(input('The choice you entered is invalid.'
                           ' Please enter a valid choice: '))

    # Return user's choice.
    return choice

def look_up(employees):
    # Get an employee ID number to look up.
    ID = input('Enter an employee ID number: ')

    # Look ID up in the dictionary. If found,
    # data will print using employee __str__ method
    # otherwise will print specified message.
    print(employees.get(ID, "The specified ID number was not found"))

def add(employees):
    # Get employee information.
    name = input('Enter employee name: ')
    ID = input('Enter employee ID number: ')
    department = input('Enter employee department: ')
    title = input('Enter employee title: ')

    new_emp = emp.Employee(name, ID, department, title)

    # Add new employee if ID does not exist.
    # otherwise notify user that ID exists.
    if ID not in employees:
        employees[ID] = new_emp
        print('The new employee has been added.')
    else:
        print('An employee with that ID already exists.')

def change(employees):
    # Get employee updated information.
    ID = input('Enter employee ID number: ')

    # Change employee information if ID exists.
    # Otherwise, notify user that ID does not exist.
    if ID in employees:
        name = input('Enter the new name: ')
        department = input('Enter the new department: ')
        title = input('Enter the new title: ')

        new_emp = emp.Employee(name, ID, department, title)

        employees[ID] = new_emp
        print('Employee information updated.')
    # ID not found.
    else: 
        print('The specified ID number was not found.')


def delete(employees):
    # Get employee updated information.
    ID = input('Enter employee ID number: ')

    # Change employee information if ID exists.
    # Otherwise, notify user that ID does not exist.
    if ID in employees:
        del employees[ID]
        print('Employee information deleted.')
    # ID not found.
    else: 
        print('The specified ID number was not found.')

# Function pickles the specified dictionary and
# saves it to the employees file.
def save_employees(employees):
    # Open the file for writing.
    output_file = open(FILENAME, 'wb')

    # Pickle the dictionary and save it.
    pickle.dump(employees, output_file)

    # Close the file.
    output_file.close()

# Call the main function.
if __name__ == '__main__':
    main()