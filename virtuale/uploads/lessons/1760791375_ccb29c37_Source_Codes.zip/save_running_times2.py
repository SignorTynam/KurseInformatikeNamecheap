# This program saves a sequence of video running times
# to the video_times.txt file.

def main():
    # Get the number of videos in the project.
    num_videos = int(input('How many videos are in the project? '))

    with open('video_times.txt', 'w') as video_file:
        print('Enter the running times for each video.')
        for count in range(1, num_videos + 1):
            run_time = float(input(f'Video #{count}: '))
            video_file.write(f'{run_time}\n')

    print('The times have been saved to video_times.txt.')

# Call the main function.
if __name__ == '__main__':
    main()