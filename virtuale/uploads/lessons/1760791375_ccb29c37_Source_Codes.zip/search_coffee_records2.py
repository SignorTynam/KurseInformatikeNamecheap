def main():
  found = False
  search = input('Jep përshkrimin që kërkon: ')
  with open('coffee.txt', 'r', encoding='utf-8') as coffee_file:
    descr = coffee_file.readline()
    while descr != '':
      qty = float(coffee_file.readline())
      descr = descr.rstrip('\n')
      if descr == search:
        print(f'Përshkrimi: {descr}')
        print(f'Sasia: {qty}\n')
        found = True
      descr = coffee_file.readline()
  if not found:
    print('Ky artikull nuk u gjet në skedar.')

if __name__ == '__main__':
  main()