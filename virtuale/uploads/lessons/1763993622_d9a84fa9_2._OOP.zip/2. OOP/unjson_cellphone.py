import json

FILENAME = 'cellphones.json'

def main():
    with open(FILENAME, 'r') as input_file:
        phone_list = json.load(input_file)
    
    for phone in phone_list:
        print('----------------------')
        print(f'Prodhuesi: {phone["manufact"]}')
        print(f'Modeli   : {phone["model"]}')
        print(f'Cmimi    : {phone["retail_price"]:.2f} €')

if __name__ == '__main__':
    main()
