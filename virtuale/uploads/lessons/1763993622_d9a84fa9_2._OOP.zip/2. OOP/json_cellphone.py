import json
import cellphone

FILENAME = 'cellphones.json'

def main():
    again = 'y'
    phone_list = []

    while again.lower() == 'y':
        man = input('Prodhuesi: ')
        mod = input('Modeli: ')
        retail = float(input('Cmimi me pakice: '))
        phone = cellphone.CellPhone(man, mod, retail)
        phone_list.append({
            'manufact': phone.get_manufact(),
            'model': phone.get_model(),
            'retail_price': phone.get_retail_price()
        })

        print('Te dhenat u ruajten.\n')
        again = input('Fut me shume telefona? (y/n): ')

    with open(FILENAME, 'w') as output_file:
        json.dump(phone_list, output_file, indent=4)

    print(f'Te dhenat u ruajten ne {FILENAME}.')

if __name__ == '__main__':
    main()
