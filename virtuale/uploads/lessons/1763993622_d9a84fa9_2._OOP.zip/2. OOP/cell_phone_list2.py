import cellphone

def main():
    phones = make_list()

    if not phones:
        print('Nuk u fut asnje telefon.')
        return

    print('Ketu jane te dhenat qe futet:\n')
    display_list(phones)

    expensive = find_most_expensive(phones)

    print('\nTelefoni me i shtrenjte:')
    print('-----------------------')
    print(f'Prodhuesi: {expensive.get_manufact()}')
    print(f'Modeli   : {expensive.get_model()}')
    print(f'Cmimi    : {expensive.get_retail_price():.2f} €')

def make_list():
    phone_list = []
    n = int(input('Sa telefona deshiron te fusesh? '))

    print()
    for count in range(1, n + 1):
        print(f'Telefoni nr. {count}:')
        man = input('  Prodhuesi: ')
        mod = input('  Modeli: ')
        retail = float(input('  Cmimi me pakice: '))
        print()

        phone = cellphone.CellPhone(man, mod, retail)
        phone_list.append(phone)

    return phone_list

def display_list(phone_list):
    for item in phone_list:
        print(f'Prodhuesi: {item.get_manufact()}')
        print(f'Modeli   : {item.get_model()}')
        print(f'Cmimi    : {item.get_retail_price():.2f} €')
        print()

def find_most_expensive(phone_list):
    if not phone_list:
        return None
    return max(phone_list, key=lambda p: p.get_retail_price())

if __name__ == '__main__':
    main()
