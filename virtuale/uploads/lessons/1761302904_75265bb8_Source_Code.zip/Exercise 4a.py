def read_float(prompt: str) -> float:
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print('Ju lutem jepni një numër të vlefshëm!')

nums = [read_float(f'Nr {i+1}/20: ') for i in range(20)]
print(min(nums), max(nums), sum(nums), sum(nums)/len(nums))
