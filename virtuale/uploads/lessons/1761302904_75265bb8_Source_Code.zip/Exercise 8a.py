def main():
    try:
        with open('BoyNames.txt', 'r', encoding='utf-8') as f:
            popular_boys = [line.strip() for line in f if line.strip()]
        with open('GirlNames.txt', 'r', encoding='utf-8') as f:
            popular_girls = [line.strip() for line in f if line.strip()]
    except IOError:
        print('Skedarët nuk u gjetën.'); return

    boy  = input("Boy's name (ose N për të anashkaluar): ").strip()
    girl = input("Girl's name (ose N për të anashkaluar): ").strip()

    if boy.upper() == 'N':
        print("S'keni futur emër djali.")
    else:
        print(f"{boy} është", "në listë." if boy in popular_boys else "JASHTË listës.")

    if girl.upper() == 'N':
        print("S'keni futur emër vajze.")
    else:
        print(f"{girl} është", "në listë." if girl in popular_girls else "JASHTË listës.")

if __name__ == '__main__':
    main()