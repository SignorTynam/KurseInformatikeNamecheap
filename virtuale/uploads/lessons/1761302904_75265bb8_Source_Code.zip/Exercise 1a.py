def main():
    days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
    sales = [float(input(f'Enter the sales for {d}: ')) for d in days]
    print(f'Total sales for the week: ${sum(sales):,.2f}')

if __name__ == '__main__':
    main()