def main():
    number = 10

    if number > 5:
        raise Exception(f"The number should not exceed 5. ({number=})")

    print(number)  # Ky rresht NUK ekzekutohet nëse ngrihet exception.

if __name__ == "__main__":
    main()