def process_file(filename):
    try:
        with open(filename) as f:
            for lineno, line in enumerate(f, 1):
                try:
                    value = float(line)
                    # Përpunim i mëtejshëm...
                except ValueError as err:
                    err.add_note(f"Gabim në rreshtin {lineno} të skedarit '{filename}': {line.strip()}")
                    raise
    except Exception as e:
        e.add_note(f"Ndodhi gabim gjatë përpunimit të skedarit '{filename}'")
        raise

if __name__ == "__main__":
    process_file("shembull.txt")
