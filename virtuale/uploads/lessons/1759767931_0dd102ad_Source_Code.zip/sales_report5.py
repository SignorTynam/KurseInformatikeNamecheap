def main():
    total = 0.0
    infile = None
    try:
        infile = open('sales_data.txt', 'r')

        for line in infile:
            amount = float(line)
            total += amount

    except Exception as err:
        print(err)
    else:
        print(f'{total:,.2f}')
    finally:
        print('Executing finally clause.')

        if infile is not None:
            infile.close()

if __name__ == '__main__':
    main()
