# Leksioni 8: Funksionet në Python - Pjesa 1

Ky leksion mbulon konceptet themelore të funksioneve: nga modularizimi dhe avantazhet e tyre, tek mënyra e definimit, thirrjes, parametrit dhe llojet (void vs. value-returning).

## 1. Çfarë është një funksion?

- **Funksion**: grup komandash që kryejnë një detyrë specifike në program.  
- **Modularizim**: “për-dekompozim” i një problemi të madh në module të vogla, të testueshme dhe të ripërdorshme.  
- **Avantazhet**:  
  1. Kodi bëhet më i thjeshtë dhe i lexueshëm.  
  2. Ripërdorimi i kodit (shkruaj një herë, thirr shumë herë).  
  3. Lehtëson testimin/debug-imin.  
  4. Nxit bashkëpunimin në skuadër.

## 2. Funksionet Void vs. Value-Returning

- **Void Function**: nuk kthen vlerë; thjesht ekzekuton veprimet e përfshira.  
- **Value-Returning Function**: ekzekuton veprimet dhe pastaj *kthen* një vlerë në thirrës.

Shembull void:

```python
def pershendetje():
    print("Përshëndetje, si je?")
# Thirrja
pershendetje()
```

Shembull value-returning:

```python
def shto(a, b):
    return a + b

rezultati = shto(5, 7)   # rezultati = 12
```

## 3. Definimi dhe Thirrja e Një Funksioni

1. Sintaksa bazë:

   ```python
   def emri_funksionit(param1, param2, ...):
       # blloku i kodit (indentohet)
       komanda1
       komanda2
       return vlerë  # opsionale
   ```

2. **Emri**: fillon me shkronjë ose under­score, pa hapësira, pa fjalë kyçe.  
3. **Thirrja**:

   ```python
   emri_funksionit(vlerë1, vlerë2, ...)
   ```

## 4. Indentimi në Python

- Çdo bllok kodi (funksion, cikël, kusht) duhet të jetë i identifikuar me të njëjtin numër hapësirash/tab.  
- Mungesa e indentimit ose përzieni tab-et me hapësira jep gabime të interpreterit.

## 5. Projektimi Top-Down dhe Hierarkia

- **Top-Down Design**: shkruaj një “skelet” me funksione bosh, pastaj plotëso çdo funksion veçmas.  
- **`pass` keyword**: hapësirë mbajtëse për funksionet që do të plotësohen më vonë.

  ```python
  def hapi1():
      pass   # Do ta implementojmë më vonë

  def hapi2():
      pass
  ```

## 6. Variablat Lokale dhe Globalë

- **Lokale**: krijohen brenda funksionit; shikueshmëria (scope) brenda atij funksioni.

  ```python
  def f():
      x = 10    # x është lokale
      print(x)
  ```

- **Globale**: krijohen jashtë çdo funksioni; mund t’u qaset çdo funksion, por ndryshimi u kërkon `global`.

  ```python
  PI = 3.14159    # tendencë për të mos ndryshuar emërtimin (konstantë)

  def ndrysho_global():
      global PI
      PI = 3       # ndikon vërtet jashtë funksionit
  ```

**Shënim**: Abuzimi me variablat globale e vështirëson debug-imin dhe ripërdorimin.

## 7. Parametrat dhe Argumentet

1. **Parametra pozicionalë**: lidhen me argumentin sipas radhës.

   ```python
   def pershendetje_emri(emri):
       print("Përshëndetje, " + emri)

   pershendetje_emri("Arta")
   ```

2. **Parametra shumëfishe**:

   ```python
   def printo_info(emri, mosha, qyteti):
       print(f"{emri}, {mosha} vjeç nga {qyteti}")

   printo_info("Beni", 30, "Tiranë")
   ```

3. **Keyword arguments**: specifikohen me emër, pa rëndësi rendi.

   ```python
   printo_info(qyteti="Durrës", emri="Elda", mosha=25)
   ```

## 8. Pass-by-Value

- Ndryshimet brenda funksionit tek parametrat nuk ndikojnë në argumentin origjinal:

  ```python
  def ndrysho(x):
      x = x + 5

  a = 10
  ndrysho(a)
  print(a)   # shtyp 10, jo 15
  ```
