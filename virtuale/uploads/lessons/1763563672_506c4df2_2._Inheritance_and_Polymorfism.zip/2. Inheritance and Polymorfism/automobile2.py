class Automobile:
    def __init__(self, make, model):
        self.__make = make
        self.__model = model

    @classmethod
    def from_string(cls, text):
        __make, __model_str = text.split('-')
        model = int(__model_str)
        return cls(__make, model)

    def __str__(self):
        return f"{self.__make} {self.__model}"

def main():
    auto1 = Automobile.from_string('Audi-2007')
    print(auto1)

if __name__ == '__main__':
    main()
