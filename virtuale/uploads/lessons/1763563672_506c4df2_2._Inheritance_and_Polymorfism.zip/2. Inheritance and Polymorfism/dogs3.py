class Automobile:
    # Atribut i klasës: numri total i automjeteve të krijuara
    __count = 0

    @classmethod
    def count(cls):
        return cls.__count

    def __init__(self, make, model):
        self.__make = make
        self.__model = model

        # Sa herë krijohet një objekt i ri, rrisim numërimin
        Automobile.__count += 1


def main():
    a1 = Automobile('Audi', 2007)
    a2 = Automobile('BMW', 2015)
    a3 = Automobile('Toyota', 2020)

    print('Janë krijuar', Automobile.count(), 'automjete.')

if __name__ == '__main__':
    main()
