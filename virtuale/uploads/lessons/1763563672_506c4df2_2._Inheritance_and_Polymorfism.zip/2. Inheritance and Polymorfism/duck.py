class Dog:
    def make_sound(self):
        print('Woof! Woof!')

class Cat:
    def make_sound(self):
        print('Meow')

class Robot:
    def make_sound(self):
        print('Beep boop!')


def play_sound(creature):
    # Duck typing: supozojmë që ka metodën make_sound
    creature.make_sound()


def main():
    d = Dog()
    c = Cat()
    r = Robot()

    play_sound(d)  # Woof! Woof!
    play_sound(c)  # Meow
    play_sound(r)  # Beep boop!

if __name__ == '__main__':
    main()
