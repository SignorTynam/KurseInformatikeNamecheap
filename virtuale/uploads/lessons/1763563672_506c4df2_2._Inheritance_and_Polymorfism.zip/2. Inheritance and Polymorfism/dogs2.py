class Automobile:
    # Atribut i klasës: numri total i automjeteve të krijuara
    count = 0

    def __init__(self, make, model):
        self.make = make
        self.model = model

        # Sa herë krijohet një objekt i ri, rrisim numërimin
        Automobile.count += 1


def main():
    a1 = Automobile('Audi', 2007)
    a2 = Automobile('BMW', 2015)
    a3 = Automobile('Toyota', 2020)

    print('Janë krijuar', Automobile.count, 'automjete.')

if __name__ == '__main__':
    main()
