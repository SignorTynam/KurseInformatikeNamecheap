class Automobile:
    __count = 0

    def __init__(self, make, model):
        self.__make = make
        self.__model = model
        Automobile.__count += 1

    @classmethod
    def how_many(cls):
        print('Deri tani janë krijuar', cls.__count, 'automjete.')

def main():
    Automobile.how_many()   # thirrje përmes klasës

    a1 = Automobile('Audi', 2007)
    a2 = Automobile('BMW', 2015)

    Automobile.how_many()   # tani count është 2
    a2.how_many()           # funksionon

if __name__ == '__main__':
    main()