class Dog:
    # Atribut i klasës: i përbashkët për të gjithë qentë
    species = 'Canis familiaris'

    def __init__(self, name, age):
        # Atribute të instancës: ndryshojnë për çdo qen
        self.name = name
        self.age = age

def main():
    d1 = Dog('Luna', 3)
    d2 = Dog('Rex', 5)

    print(d1.name, d1.age, d1.species)
    print(d2.name, d2.age, d2.species)

    # Mund të lexojmë atributin e klasës edhe nga vetë klasa
    print('Specia e të gjithë qenve është:', Dog.species)

if __name__ == '__main__':
    main()
