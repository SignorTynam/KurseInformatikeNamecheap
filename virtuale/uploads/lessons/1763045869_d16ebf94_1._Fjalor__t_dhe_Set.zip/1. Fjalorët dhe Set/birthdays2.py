# This program uses a dictionary to keep friends'
# names and birthdays.
import pickle

# Global constants for menu choices
LOOK_UP = 1; ADD = 2; CHANGE = 3; DELETE = 4; QUIT = 5; SAVE = 6; LOAD = 7


DB_FILE = 'birthdays.db'  # emri i skedarit binar

def main():
    birthdays = {}            # ose: birthdays = load_db()
    choice = 0
    while choice != QUIT:
        choice = get_menu_choice()
        if choice == LOOK_UP:   look_up(birthdays)
        elif choice == ADD:     add(birthdays)
        elif choice == CHANGE:  change(birthdays)
        elif choice == DELETE:  delete(birthdays)
        elif choice == SAVE:    save_db(birthdays)
        elif choice == LOAD:    birthdays = load_db()

def save_db(birthdays, filename=DB_FILE):
    with open(filename, 'wb') as f:
        pickle.dump(birthdays, f, protocol=pickle.HIGHEST_PROTOCOL)
    print(f'Saved {len(birthdays)} entries to {filename}')

def load_db(filename=DB_FILE):
    try:
        with open(filename, 'rb') as f:
            data = pickle.load(f)
        print(f'Loaded {len(data)} entries from {filename}')
        return data
    except FileNotFoundError:
        print('No DB found. Starting with an empty dictionary.')
        return {}

def get_menu_choice():
    print('\nFriends and Their Birthdays')
    print('---------------------------')
    print('1. Look up a birthday')
    print('2. Add a new birthday')
    print('3. Change a birthday')
    print('4. Delete a birthday')
    print('5. Quit the program')
    print('6. Save to disk (pickle)')
    print('7. Load from disk (pickle)\n')
    choice = int(input('Enter your choice: '))
    while choice < LOOK_UP or choice > LOAD:
        choice = int(input('Enter a valid choice: '))
    return choice

# The look_up function looks up a name in the
# birthdays dictionary.
def look_up(birthdays):
    # Get a name to look up.
    name = input('Enter a name: ')

    # Look it up in the dictionary.
    print(birthdays.get(name, 'Not found.'))

# The add function adds a new entry into the
# birthdays dictionary.
def add(birthdays):
    # Get a name and birthday.
    name = input('Enter a name: ')
    bday = input('Enter a birthday: ')

    # If the name does not exist, add it.
    if name not in birthdays:
        birthdays[name] = bday
    else:
        print('That entry already exists.')

# The change function changes an existing
# entry in the birthdays dictionary.
def change(birthdays):
    # Get a name to look up.
    name = input('Enter a name: ')

    if name in birthdays:
        # Get a new birthday.
        bday = input('Enter the new birthday: ')

        # Update the entry.
        birthdays[name] = bday
    else:
        print('That name is not found.')

# The delete function deletes an entry from the
# birthdays dictionary.
def delete(birthdays):
    # Get a name to look up.
    name = input('Enter a name: ')

    # If the name is found, delete the entry.
    if name in birthdays:
        del birthdays[name]
    else:
        print('That name is not found.')

# Call the main function.
if __name__ == '__main__':
    main()