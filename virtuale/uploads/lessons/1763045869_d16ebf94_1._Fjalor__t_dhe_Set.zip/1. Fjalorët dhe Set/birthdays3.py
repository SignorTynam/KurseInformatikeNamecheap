import json

LOOK_UP = 1
ADD = 2
CHANGE = 3
DELETE = 4
QUIT = 5
SAVE = 6
LOAD = 7
EXPORT_JSON = 8
IMPORT_JSON = 9

JSON_FILE = 'birthdays.json'

def main():
    birthdays = {}
    choice = 0
    while choice != QUIT:
        choice = get_menu_choice()
        if choice == LOOK_UP:          look_up(birthdays)
        elif choice == ADD:            add(birthdays)
        elif choice == CHANGE:         change(birthdays)
        elif choice == DELETE:         delete(birthdays)
        elif choice == SAVE:           save_db(birthdays)
        elif choice == LOAD:           birthdays = load_db()
        elif choice == EXPORT_JSON:    export_json(birthdays)
        elif choice == IMPORT_JSON:    birthdays = import_json()

def get_menu_choice():
    print('\nFriends and Their Birthdays')
    print('---------------------------')
    print('1. Look up a birthday')
    print('2. Add a new birthday')
    print('3. Change a birthday')
    print('4. Delete a birthday')
    print('5. Quit the program')
    print('6. Save to disk (pickle)')
    print('7. Load from disk (pickle)')
    print('8. Export to JSON')
    print('9. Import from JSON\n')
    choice = int(input('Enter your choice: '))
    while choice < LOOK_UP or choice > IMPORT_JSON:
        choice = int(input('Enter a valid choice: '))
    return choice

def save_db(birthdays, filename=JSON_FILE):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(birthdays, f, ensure_ascii=False, indent=2, sort_keys=True)
    print(f'Saved {len(birthdays)} entries to {filename}')

def load_db(filename=JSON_FILE):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
        print(f'Loaded {len(data)} entries from {filename}')
        return data
    except FileNotFoundError:
        print('No DB found. Starting with an empty dictionary.')
        return {}

def export_json(birthdays, filename=JSON_FILE):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(birthdays, f, ensure_ascii=False, indent=2, sort_keys=True)
    print(f'Exported {len(birthdays)} entries to {filename}')

def import_json(filename=JSON_FILE):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            print('Invalid JSON format (expected an object/dict).'); return {}
        print(f'Imported {len(data)} entries from {filename}')
        return data
    except FileNotFoundError:
        print('JSON file not found.'); return {}
    except json.JSONDecodeError as e:
        print('Invalid JSON:', e); return {}

# The look_up function looks up a name in the
# birthdays dictionary.
def look_up(birthdays):
    # Get a name to look up.
    name = input('Enter a name: ')

    # Look it up in the dictionary.
    print(birthdays.get(name, 'Not found.'))

# The add function adds a new entry into the
# birthdays dictionary.
def add(birthdays):
    # Get a name and birthday.
    name = input('Enter a name: ')
    bday = input('Enter a birthday: ')

    # If the name does not exist, add it.
    if name not in birthdays:
        birthdays[name] = bday
    else:
        print('That entry already exists.')

# The change function changes an existing
# entry in the birthdays dictionary.
def change(birthdays):
    # Get a name to look up.
    name = input('Enter a name: ')

    if name in birthdays:
        # Get a new birthday.
        bday = input('Enter the new birthday: ')

        # Update the entry.
        birthdays[name] = bday
    else:
        print('That name is not found.')

# The delete function deletes an entry from the
# birthdays dictionary.
def delete(birthdays):
    # Get a name to look up.
    name = input('Enter a name: ')

    # If the name is found, delete the entry.
    if name in birthdays:
        del birthdays[name]
    else:
        print('That name is not found.')

# Call the main function.
if __name__ == '__main__':
    main()