def main():
    with open('cities.txt', 'r', encoding='utf-8') as infile:
        cities = infile.readlines()

    # Hiq '\n' nga çdo element
    for i in range(len(cities)):
        cities[i] = cities[i].rstrip('\n')

    print(cities)

if __name__ == '__main__':
    main()
