def main():
    cities = ['New York', 'Boston', 'Atlanta', 'Dallas']
    with open('cities.txt', 'w', encoding='utf-8') as outfile:
        for item in cities:
            print(item, file=outfile)

if __name__ == '__main__':
    main()
