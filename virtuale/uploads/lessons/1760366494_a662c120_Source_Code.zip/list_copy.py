def main():

    list1 = [1, 2, 3]

    # MENYRA 1
    # Kopjimi i listes duke perdorur metoden copy()
    list3 = list1.copy()
    print("Lista 3:", list3)

    # MENYRA 2
    # Kopjimi i listes duke perdorur metoden list()
    list4 = list(list1)
    print("Lista 4:", list4)

    # MENYRA 3
    # Kopjimi i listes duke perdorur slicing
    list5 = list1[:]
    print("Lista 5:", list5)

    # MENYRA 4 
    # Duke perdorur ciklin for

    list6 = []
    for i in list1:
        list6.append(i)

    print("Lista 6:", list6)

    # MENYRA 5 
    # Duke perdorur [] + list

    list7 = [] + list1
    print("Lista 7:", list7)
main()