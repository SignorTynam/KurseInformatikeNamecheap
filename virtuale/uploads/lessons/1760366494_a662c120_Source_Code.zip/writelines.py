def main():
    cities = ['New York', 'Boston', 'Atlanta', 'Dallas']
    with open('cities.txt', 'w', encoding='utf-8') as outfile:
        outfile.writelines(cities)   # -> të gjitha në një rresht!

if __name__ == '__main__':
    main()
