def main():

    numbers = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
    min_value = min(numbers)
    max_value = max(numbers)

    print(f"Minimum value: {min_value}")
    print(f"Maximum value: {max_value}")

main()