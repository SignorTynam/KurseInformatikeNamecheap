def main():

    numbers = [3, 1, 2]

    print("Lista e numrave:")
    print(numbers)

    numbers.sort()

    print("Lista e numrave pasi eshte renditur:")
    print(numbers)

    numbers.sort(reverse=True)

    print("Lista e numrave pasi eshte renditur ne rendin e kundert:")
    print(numbers)

    emra = ['John', 'James', 'Jack', 'Jerry']

    print("Lista e emrave:")
    print(emra)

    emra.sort()

    print("Lista e emrave pasi eshte renditur ne rendin alfabetik:")
    print(emra)

    emra.sort(reverse=True)

    print("Lista e emrave pasi eshte renditur ne rendin alfabetik te kundert:")
    print(emra)

main()