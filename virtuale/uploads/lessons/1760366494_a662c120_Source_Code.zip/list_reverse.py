def main():

    numrat = [5, 10, 9]
    print("Lista e numrave:")
    print(numrat)

    numrat.reverse()

    print("Lista e numrave pasi eshte kthyer mbrapsht:")
    print(numrat)

main()