def main():

    numbers = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
    print("List of numbers:", numbers)

    del numbers[0]  # Remove the first element
    print("After removing the first element:", numbers)

    del numbers[-1]  # Remove the last element
    print("After removing the last element:", numbers)

main()