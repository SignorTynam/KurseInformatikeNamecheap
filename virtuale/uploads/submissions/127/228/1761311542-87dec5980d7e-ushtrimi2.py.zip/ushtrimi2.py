import random

def main():
    lottery_numbers = []

    for _ in range(9): 
        number = random.randint(0, 9)
        lottery_numbers.append(number)

    print("Lottery numbers are:")
    for n in lottery_numbers:
        print(n, end='')

    print() 

if __name__ == "__main__":
    main()
