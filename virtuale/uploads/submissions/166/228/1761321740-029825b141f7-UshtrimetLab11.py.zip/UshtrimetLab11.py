
def is_prime(num):
    """Return True if num is a prime number, otherwise False."""
    if num < 2:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True


def main():
    n = int(input("Enter a number greater than 1: "))

    numbers = list(range(2, n + 1))

    for num in numbers:
        if is_prime(num):
            print(num, "is prime")
        else:
            print(num, "is not prime")


if __name__ == "__main__":
    main()
