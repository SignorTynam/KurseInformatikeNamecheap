def show_greater_numbers():
    try:
        numbers = input("Enter numbers separated by spaces: ").split()
        numbers = [float(num) for num in numbers] 
        n = float(input("Enter a number: "))

        print("Numbers greater than", n, ":")
        for num in numbers:
            if num > n:
                print(num)
    except ValueError:
        print("Error: Please enter only numbers!")

show_greater_numbers()
