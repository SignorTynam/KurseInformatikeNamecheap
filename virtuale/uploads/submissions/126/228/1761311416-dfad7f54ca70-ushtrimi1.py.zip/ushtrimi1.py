def main():
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    sales = []

    for day in days:
        while True:
            try:
                amount = float(input(f"Enter sales for {day}: "))
                sales.append(amount)
                break
            except ValueError:
                print("Invalid input! Please enter a number.")

    total = sum(sales)
    print(f"\nWeekly total sales: {total:.2f}")


if __name__ == "__main__":
    main()
