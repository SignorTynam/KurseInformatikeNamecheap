def main():
    filename = "steps.txt"

    try:
        infile = open(filename, "r")
        steps = [int(line.strip()) for line in infile]
        infile.close()

        days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        month_names = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ]

        index = 0
        for month, days in enumerate(days_in_month):
            month_steps = steps[index:index + days]
            average = sum(month_steps) / len(month_steps)
            print(f"{month_names[month]}: {average:.2f} average steps")
            index += days

    except FileNotFoundError:
        print("The file", filename, "was not found.")
    except ValueError:
        print("The file contains invalid data.")
    except Exception as err:
        print("An error occurred:", err)


if __name__ == "__main__":
    main()
