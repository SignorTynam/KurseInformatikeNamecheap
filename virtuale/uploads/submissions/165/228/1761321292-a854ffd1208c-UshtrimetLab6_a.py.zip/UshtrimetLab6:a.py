
def main():
    numbers = input("Enter numbers separated by spaces: ").split()
    numbers = [float(num) for num in numbers]  # convert to numbers
    
    n = float(input("Enter a number n: "))
    
    greater_nums = [num for num in numbers if num > n]
    
    print(f"Numbers greater than {n} are:")
    for num in greater_nums:
        print(num)

if __name__ == "__main__":
    main()
