def main():
    filename = "numbers.txt"
    try:
        infile = open(filename, "r")
        contents = infile.read()
        print(contents)
        infile.close()
    except FileNotFoundError:
        print("The file", filename, "was not found.")
    except Exception as err:
        print("An error occurred:", err)


if __name__ == "__main__":
    main()
