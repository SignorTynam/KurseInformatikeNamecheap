def main():
    filename = input("Enter a filename: ")

    try:
        infile = open(filename, "r")
        count = 0

        for line in infile:
            print(line.strip())
            count += 1
            if count == 5:
                break

        infile.close()

    except FileNotFoundError:
        print("The file", filename, "was not found.")
    except Exception as err:
        print("An error occurred:", err)


if __name__ == "__main__":
    main()
