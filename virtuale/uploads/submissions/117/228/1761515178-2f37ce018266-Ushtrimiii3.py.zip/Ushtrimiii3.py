def main():
    filename = input("Enter a filename: ")

    try:
        infile = open(filename, "r")

        line_number = 1
        for line in infile:
            print(f"{line_number}. {line.strip()}")
            line_number += 1

        infile.close()

    except FileNotFoundError:
        print("The file", filename, "was not found.")
    except Exception as err:
        print("An error occurred:", err)


if __name__ == "__main__":
    main()
