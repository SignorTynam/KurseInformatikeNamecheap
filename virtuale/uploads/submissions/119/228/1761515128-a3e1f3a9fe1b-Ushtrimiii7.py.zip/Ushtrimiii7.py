import random

def main():
    filename = "random_numbers.txt"

    try:
        total_numbers = int(input("How many numbers should the file contain? "))

        outfile = open(filename, "w")

        for _ in range(total_numbers):
            number = random.randint(1, 500)
            outfile.write(str(number) + "\n")

        outfile.close()
        print("File", filename, "has been created with", total_numbers, "random numbers.")

    except ValueError:
        print("Please enter a valid integer for the number of values.")
    except Exception as err:
        print("An error occurred:", err)


if __name__ == "__main__":
    main()
