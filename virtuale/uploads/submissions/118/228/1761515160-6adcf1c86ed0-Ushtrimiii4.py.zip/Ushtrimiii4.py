def main():
    filename = "names.txt"

    try:
        infile = open(filename, "r")

        count = 0
        for line in infile:
            count += 1

        infile.close()
        print("The file contains", count, "names.")

    except FileNotFoundError:
        print("The file", filename, "was not found.")
    except Exception as err:
        print("An error occurred:", err)


if __name__ == "__main__":
    main()
